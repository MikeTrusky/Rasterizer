#include <iostream>
#include "TGABuffer.h"
#include "Color.h"
#include "Triangle.h"
#include "Helper.h"
#include "Rasterizer.h"

int main()
{
	TGABuffer colorBuffer = TGABuffer(500, 500);
	Rasterizer rasterizer = Rasterizer(colorBuffer);

	Color color(0, 0, 0, 0);
	Triangle triangle = Triangle(float3(-0.9f, -0.9f, 0.0f), float3(0.0f, 0.5f, 0.0f), float3(0.5f, -0.5f, 0.0f));
	colorBuffer.clearColor(color);
	rasterizer.DrawTriangle(triangle);
	colorBuffer.saveFile("outputFile.tga");

	return 0;
}