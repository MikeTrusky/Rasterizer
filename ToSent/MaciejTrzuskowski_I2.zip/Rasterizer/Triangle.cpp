#include "Triangle.h"

Triangle::Triangle(float3 v1, float3 v2, float3 v3)
{
	vertices[1] = v1;
	vertices[2] = v2;
	vertices[3] = v3;
}
