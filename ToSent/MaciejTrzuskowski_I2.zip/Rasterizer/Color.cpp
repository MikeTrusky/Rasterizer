#include "Color.h"

uint32_t Color::ToUint32_t() const
{
	return ((uint32_t)A << 24) | ((uint32_t)R << 16) | ((uint32_t)G << 8) | (uint32_t)B;
}
