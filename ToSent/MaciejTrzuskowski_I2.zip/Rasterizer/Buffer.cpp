#include "Buffer.h"

Buffer::Buffer(int w, int h) : w(w), h(h)
{
	setSize(w * h);
}

void Buffer::setSize(int size)
{
	frame = new uint32_t[size];
}

void Buffer::clearColor(Color &color)
{
	for(int i = 0; i < w; i++)
		for (int j = 0; j < h; j++)
		{
			setPixelColor(i, j, color);
		}
}

void Buffer::clearDepth()
{
}

void Buffer::setPixelColor(int x, int y, const Color &color)
{
	frame[y * w + x] = color.ToUint32_t();
}
