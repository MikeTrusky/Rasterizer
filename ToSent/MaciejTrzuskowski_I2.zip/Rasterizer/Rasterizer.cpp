#include "Rasterizer.h"

inline int min(int a, int b, int c)
{
	return a < b ? (a < c ? a : c) : (b < c ? b : c);
}

inline int max(int a, int b, int c)
{
	return a < b ? (b < c ? c : b) : (a < c ? c : a);
}

void Rasterizer::DrawTriangle(Triangle & triangle)
{
#pragma region Kanoniczna bry�a widzenia
	float x1 = CalculateCanonicalViewX(triangle.vertices[0].x);
	float x2 = CalculateCanonicalViewX(triangle.vertices[1].x);
	float x3 = CalculateCanonicalViewX(triangle.vertices[2].x);

	float y1 = CalculateCanonicalViewY(triangle.vertices[0].y);
	float y2 = CalculateCanonicalViewY(triangle.vertices[1].y);
	float y3 = CalculateCanonicalViewY(triangle.vertices[2].y);
#pragma endregion

	buffer.minx = (int)min(x1, x2, x3);
	buffer.maxx = (int)max(x1, x2, x3);
	buffer.miny = (int)min(y1, y2, y3);
	buffer.maxy = (int)max(y1, y2, y3);

#pragma region Sta�e
	float x12 = x1 - x2;
	float x13 = x1 - x3;
	float x23 = x2 - x3;
	float x32 = x3 - x2;
	float x31 = x3 - x1;

	float y12 = y1 - y2;
	float y13 = y1 - y3;
	float y23 = y2 - y3;
	float y31 = y3 - y1;
#pragma endregion

	for (int x = buffer.minx; x < buffer.maxx; x++)
	{
		for (int y = buffer.miny; y < buffer.maxy; y++)
		{
			if (x12 * (y - y1) - y12 * (x - x1) > 0 &&
				x23 * (y - y2) - y23 * (x - x2) > 0 &&
				x31 * (y - y3) - y31 * (x - x3) > 0)
			{
				buffer.setPixelColor(x, y, Color(255.0f, 255.0f, 0.0f, 0.0f));
			}
		}
	}
}

float Rasterizer::CalculateCanonicalViewX(float x)
{
	return (x + 1) * buffer.w * 0.5f;
}

float Rasterizer::CalculateCanonicalViewY(float y)
{
	return (y + 1) * buffer.h * 0.5f;
}